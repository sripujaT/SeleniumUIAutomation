package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AutomationCarVehicle {
	
	WebDriver driver;
	
	By CarVehicle=(By.xpath("//*[@id=\"main-container\"]/header/div[2]/div/div[2]/div/div[2]/ul/li[1]/a"));
	By CTPInsurance=(By.xpath("//*[@id=\"main-container\"]/header/div[2]/div/div[2]/div/div[2]/ul/li[1]/ul/li[2]/ul/li[2]/ul/li[2]/a"));
	By ChooseState=(By.xpath("//div[@class='c-columnContent container']//div[1]//div[2]//a[1]"));
	
public AutomationCarVehicle (WebDriver driver) {
	this.driver = driver;
}
	public AutomationCarVehicle() {
	// TODO Auto-generated constructor stub
}
	public WebElement CarVehicle() {
		return driver.findElement(CarVehicle);
	}
	public WebElement CTPInsurance() {
		return driver.findElement(CTPInsurance);
	}
	public WebElement ChooseState() {
		return driver.findElement(ChooseState);
	}
}

