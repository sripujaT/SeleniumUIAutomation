package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CustomerDetails {
	WebDriver driver;

	By FillDetails = (By.xpath("//label[contains(text(),'Individual / sole trader')]//input[@name='customertype']"));
	By Insurance = (By.cssSelector("input[value='A']"));
	By ClickNo = (By.xpath("//label[contains(text(),'No')]//input[@name='tax']"));
	By DOB = (By.xpath("//input[@id='dob']"));
	By Continue = (By.xpath("//button[@id='button_forward']"));
	By Finish = (By.xpath("//button[@id='button_forward']"));

	public CustomerDetails(WebDriver driver) {
		this.driver = driver;
	}

	public CustomerDetails() {
		// TODO Auto-generated constructor stub
	}

	public WebElement FillDetails() {
		return driver.findElement(FillDetails);
	}

	public WebElement Insurance() {
		return driver.findElement(Insurance);
	}

	public WebElement ClickNo() {
		return driver.findElement(ClickNo);
	}

	public WebElement DOB() {
		return driver.findElement(DOB);
	}

	public WebElement Continue() {
		return driver.findElement(Continue);

	}

	public WebElement Finish() {
		return driver.findElement(Finish);

	}
}
