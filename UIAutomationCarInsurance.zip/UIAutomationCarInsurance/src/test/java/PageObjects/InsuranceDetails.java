package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class InsuranceDetails {
	WebDriver driver;

	By RenewGreenSlip = (By.xpath("//*[@id=\"actionbar\"]/li[2]/a"));
	By clickButton = (By.cssSelector("#button_get-quote"));
	By plateNumber=(By.xpath("//div[@class='col-sm-5 qbe-col-slim-right']//div[1]//label[1]//div[1]"));
	By vehicleNumber=(By.xpath("//div[contains(text(),'Using other numbers instead, such as')]"));
	By AnonymousQuote = (By.xpath("//*[@id=\"gsp\"]/div[4]/div/div[1]/qbe-question/div[2]/div[3]/label/input"));
	By SelectCurrent = (By.xpath("//form[@id='form-3']//select[@id='rms_vehicle_origin']"));
	By InsuranceStartDate = (By.xpath("//*[@id=\"ui-datepicker-div\"]/table/tbody/tr[4]/td[3]/a"));
	By ClickContinue = (By.xpath("//form[@id='form-3']//button[@id='btn_continue']"));

	public InsuranceDetails(WebDriver driver) {
		this.driver = driver;
	}

	public InsuranceDetails() {
		// TODO Auto-generated constructor stub
	}

	public WebElement RenewGreenSlip() {
		return driver.findElement(RenewGreenSlip);
	}

	public WebElement clickButton() {
		return driver.findElement(clickButton);
	}
	public WebElement plateNumber() {
		return driver.findElement(plateNumber);
	}
	public WebElement vehicleNumber() {
		return driver.findElement(vehicleNumber);
	}

	public WebElement AnonymousQuote() {
		return driver.findElement(AnonymousQuote);
	}

	public WebElement SelectCurrent() {
		return driver.findElement(SelectCurrent);
	}

	public WebElement InsuranceStartDate() {
		return driver.findElement(InsuranceStartDate);
	}

	public WebElement ClickContinue() {
		return driver.findElement(ClickContinue);
	}

}
