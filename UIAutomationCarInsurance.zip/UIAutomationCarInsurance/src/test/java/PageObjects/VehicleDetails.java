package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class VehicleDetails {
	WebDriver driver;
	//Read the data directly from the script
	String vehicletype= selectbyvisibletext("HOLDEN");
	String Vehicleshape=selectbyvisibletext("SED");
	String Vehicleusage=selectbyvisibletext("PRIV");

	By manufacture = (By.id("a2"));
	By VehicleShape = (By.id("a3"));
	By VehicleUsage = (By.id("a4"));
	By suburb = (By.id("a5"));
	By Tapcontinue = (By.xpath("//button[@id='button_forward']"));

	public VehicleDetails(WebDriver driver) {
		this.driver = driver;
	}

	private String selectbyvisibletext(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	public VehicleDetails() {
		// TODO Auto-generated constructor stub
	}

	public WebElement Manufacture() {
		return driver.findElement(manufacture);
	}

	public WebElement VehicleShape() {
		return driver.findElement(VehicleShape);
	}

	public WebElement VehicleUsage() {
		return driver.findElement(VehicleUsage);
	}

	public WebElement suburb() {
		return driver.findElement(suburb);
	}

	public WebElement Tapcontinue() {
		return driver.findElement(Tapcontinue);
	}

}
