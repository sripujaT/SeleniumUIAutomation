package Automationpackage;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import PageObjects.AutomationCarVehicle;
import PageObjects.CustomerDetails;
import PageObjects.InsuranceDetails;
import PageObjects.VehicleDetails;
import Resources.BrowserloginTest;

@Test
public class LaunchAutomation extends BrowserloginTest {
	@BeforeTest
	public void launch() throws IOException, InterruptedException {
		driver = initialization();
		Thread.sleep(5000);
	}

	public void Acar() {
		AutomationCarVehicle auto = new AutomationCarVehicle(driver);
		auto.CarVehicle().click();
		auto.CTPInsurance().click();
		auto.ChooseState().click();
	}

	public void BInsurance() {
		InsuranceDetails insurance = new InsuranceDetails(driver);
		insurance.RenewGreenSlip().click();
		insurance.clickButton().click();
		insurance.plateNumber().click();
		insurance.vehicleNumber().click();
		insurance.AnonymousQuote().click();
		insurance.SelectCurrent().click();
		insurance.InsuranceStartDate().click();
		insurance.ClickContinue().click();
	}

	public void CVehicleDetails() {
		VehicleDetails vehicle = new VehicleDetails(driver);
		vehicle.Manufacture().click();
		vehicle.VehicleShape().click();
		vehicle.VehicleUsage().click();
		vehicle.suburb().click();
		vehicle.Tapcontinue().click();
	}

	public void DCustomerDetails() {
		CustomerDetails customerdetails = new CustomerDetails(driver);
		customerdetails.FillDetails().click();
		customerdetails.Insurance().click();
		customerdetails.ClickNo().click();
		customerdetails.DOB().click();
		customerdetails.Continue().click();
		customerdetails.Finish().click();
	}
}
