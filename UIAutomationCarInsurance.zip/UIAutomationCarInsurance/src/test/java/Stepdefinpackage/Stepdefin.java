package Stepdefinpackage;

import cucumber.api.Result;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import cucumber.api.junit.Cucumber;
import java.util.List;

import org.junit.Assert;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import PageObjects.InsuranceDetails;

@RunWith(Cucumber.class)
public class Stepdefin {
	int result = 3;
	WebDriver driver;

	@Given("^Initialize the chrome browser and url is launched$")
	public void initialize_the_chrome_browser_and_url_is_launched() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\777633\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.qbe.com/au");
		driver.manage().window().maximize();
		System.out.println("launches the Car Insurance url");
		// count and print the menulinks
		int Count = driver.findElements(By.tagName("a")).size();
		System.out.println("Total number of links on launch page is" + Count);
		List<WebElement> menulinks = driver.findElements(By.tagName("a"));
		int AllLinks = menulinks.size();
		System.out.println("Total number of links on launch page is" + AllLinks);
		Thread.sleep(1000);
		for (int i = 1; i < Count; i++) {
			String displayLinks = driver.findElements(By.tagName("a")).get(i).getAttribute("href");
			System.out.println(displayLinks);
		}
	}

	@When("^click Car and Vehicle and CTP Insurance$")
	public void click_car_and_vehicle_and_ctp_insurance() throws Throwable {
		driver.findElement(By.linkText("Car & Vehicle")).click();
		Thread.sleep(1000);
		System.out.println("click Car &Vehicle");
		driver.findElement(By.linkText("CTP")).click();
		System.out.println("click CTP");
		Thread.sleep(1000);
		// verify the text Compulsory Third Party NSW
		if (driver.getPageSource().contains("Compulsory Third Party NSW")) {
			System.out.println("Text matched");
		} else {
			System.out.println("Text does not match");
		}
		Thread.sleep(2000);
		String actual_text = (driver.findElement(By.xpath("//div[@class='c-banner__description hidden-xs']")))
				.getText();
		String expected_text = "Compulsory Third Party NSW";
		Assert.assertTrue(expected_text.contains("Compulsory Third Party NSW"));
		// verify title of the page
		String page_title = driver.getTitle();
		String expectedTitle = "CTP Green Slip insurance | QBE AU";
		if (page_title.equalsIgnoreCase(expectedTitle)) {
			System.out.println("Title Matched");
		} else {
			System.out.println("Title does not match");
			Thread.sleep(10000);
		}
		// NSW find out more link
		driver.findElement(By.xpath("//div[@class='c-columnContent container']//div[1]//div[2]//a[1]")).click();
		System.out.println("choose state NSW");
		Thread.sleep(2000);
	}

	@When("^Click on the “Renew your Green Slip” Icon$")
	public void click_on_the_renew_your_green_slip_icon() throws Throwable {
		System.out.println("Renew your Green Slip");
		driver.findElement(By.xpath("//*[@id=\"actionbar\"]/li[2]/a")).click();
		Thread.sleep(1000);
		// get a quote
		driver.findElement(By.cssSelector("#button_get-quote")).click();
		System.out.println("get quote");
		Thread.sleep(1000);
	}

	@Then("^Select an Anonymous Quote radio button$")
	public void select_an_anonymous_quote_radio_button() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"gsp\"]/div[4]/div/div[1]/qbe-question/div[2]/div[3]/label/input"))
				.click();
		System.out.println("clicks radio button");
		Thread.sleep(1000);
		// Select the anonymous quote radio button
		InsuranceDetails insurance = new InsuranceDetails(driver);
		switch (result) {

		case 1:

			insurance.plateNumber().click();
			break;
		case 2:
			insurance.vehicleNumber().click();
			break;
		case 3:
			insurance.AnonymousQuote().click();
			System.out.println("Anonymous quote is selected");
			break;
		}
	}

	@Then("^Select “Is the Vehicle” as current from the drop down$")
	public void select_is_the_vehicle_as_current_from_the_drop_down() throws Throwable {
		Thread.sleep(1000);
		WebElement dropdown = driver.findElement(By.xpath("//form[@id='form-3']//select[@id='rms_vehicle_origin']"));
		System.out.println("before click");
		Select s = new Select(dropdown);
		Thread.sleep(1000);
		s.selectByValue("1");
		System.out.println("Current is selected from the drop-down list");
//verify title of the page loaded step 8
		String page_title = driver.getTitle();
		System.out.println("page title is" + page_title);
		String expected_title = "QBE Insurance Group - NSW Green Slips";
		if (page_title.equalsIgnoreCase(expected_title))
			System.out.println("Title matched");
		else
			System.out.println("Title does not match");
	}

	@Then("^Input any future date as “Insurance Start Date”$")
	public void input_any_future_date_as_insurance_start_date() throws Throwable {
		driver.findElement(By.id("form-3_start_date")).click();
		driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/table/tbody/tr[4]/td[3]/a")).click();
		System.out.println("date has selected");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//form[@id='form-3']//button[@id='btn_continue']")).click();
	}

	@Then("^Fill in all the details in the Vehicle screen and click continue$")
	public void fill_in_all_the_details_in_the_vehicle_screen_and_click_continue() throws Throwable {
		driver.findElement(By.id("a1")).sendKeys("2013");
		Select s = new Select(driver.findElement(By.id("a2")));
		s.selectByValue("HOLDEN");
		Thread.sleep(1000);
		// shape
		Select s1 = new Select(driver.findElement(By.id("a3")));
		s1.selectByValue("SED");
		System.out.println("shape of the car is Sedan");
		// usage
		Select s2 = new Select(driver.findElement(By.id("a4")));
		s2.selectByValue("PRIV");
		System.out.println(" Private car");
		Thread.sleep(1000);
		// address
		Select s3 = new Select(driver.findElement(By.id("a5")));
		s3.selectByValue("2000-SYDNEY");
		System.out.println(" postcode is 2000- Sydney");
		// continue
		driver.findElement(By.xpath("//button[@id='button_forward']")).click();
		Thread.sleep(1000);
	}

	@Then("^Fill in the “Details” page and click continue$")
	public void fill_in_the_details_page_and_click_continue() throws Throwable {
		driver.findElement(
				By.xpath("//label[contains(text(),'Individual / sole trader')]//input[@name='customertype']")).click();
		driver.findElement(By.cssSelector("input[value='A']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//label[contains(text(),'No')]//input[@name='tax']")).click();
		driver.findElement(By.id("dob")).sendKeys("18/06/1997");
		driver.findElement(By.xpath("//input[@id='dob']")).click();
		driver.findElement(By.xpath("//button[@id='button_forward']")).click();
		Thread.sleep(8000);
		// verify all the input fields
		String car_type = driver.findElement(By.xpath("//div[@class='row']//b[contains(text(),'HOLDEN')]")).getText();
		String expected_type = "HOLDEN";
		Assert.assertEquals(expected_type, car_type);
		System.out.println("Car type matched");
	}

	@Then("^Click on “Finished”$")
	public void click_on_finished() throws Throwable {
		driver.findElement(By.xpath("//button[@id='button_forward']")).click();
		System.out.println("Click Finished");
	}

	@Given("^Initialize the firefox browser and url is launched$")
	public void initialize_the_firefox_browser_and_url_is_launched() throws Throwable {
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\777633\\geckodriver.exe");
		driver = new FirefoxDriver();
		driver.get("https://www.qbe.com/au");
		driver.manage().window().maximize();
		System.out.println("launches the Car Insurance url in firefox");
	}

}
