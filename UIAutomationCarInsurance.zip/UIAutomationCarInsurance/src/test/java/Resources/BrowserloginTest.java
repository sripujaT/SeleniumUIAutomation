package Resources;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BrowserloginTest {
	public WebDriver driver;

	public WebDriver initialization() throws IOException {
		Properties prop = new Properties();
		FileInputStream fs = new FileInputStream(
				"C:\\Users\\777633\\eclipse-workspace\\UIAutomationCarInsurance\\src\\test\\java\\Resources\\data.properties");
		prop.load(fs);
		String browsername = prop.getProperty("browser");
		if (browsername.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\777633\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.get(prop.getProperty("url"));
		} else if (browsername.equalsIgnoreCase("Firefox")) {
			System.setProperty("webdriver.gecko.driver", "C:\\Users\\777633\\geckodriver.exe");
			driver = new FirefoxDriver();
			driver.get(prop.getProperty("url"));
		}
		driver.close();
		driver.quit();
		return driver;
		
	}
}
